# Issues

- Does it load the fonts? Need to check this on a web server.
- Does not show the plugin content!
