from django.apps import AppConfig


class DjangocmsStaticConfig(AppConfig):
    name = 'djangocms_static'
