# djangocms-static

Static sites generator for Django CMS.

This repo is in an early develpment stage.

# How to test the add-on

1. Set up your own Django CMS to test it on.
1. Copy the file `djangocms-static-0.1.tar.gz` (located in the dist folder) in the same directory as your `manage.py`.
1. Add `djangocms_static` to your installed apps.

    INSTALLED_APPS = [
        'djangocms_static',
        ...
    ]

1. Add the static urls to your project `urls.py`:

    urlpatterns = [
        path("sitemap.xml", sitemap, {"sitemaps": {"cmspages": CMSSitemap}}),
        path("static_generator/", include('djangocms_static.urls')),
    ]
